import { Component } from '@angular/core';

@Component({
  selector: 'app-export-lock',
  imports: [],
  templateUrl: './export-lock.html',
  styleUrl: './export-lock.scss',
})
export class ExportLock {

}
