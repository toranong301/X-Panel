import { Component } from '@angular/core';

@Component({
  selector: 'app-fr04-preview',
  imports: [],
  templateUrl: './fr04-preview.html',
  styleUrl: './fr04-preview.scss',
})
export class Fr04Preview {

}
