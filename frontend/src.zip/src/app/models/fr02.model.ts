export interface Fr02Data {
  orgChartImage?: string; // base64
  note?: string;
}
