import { Injectable } from '@angular/core';
import { InventoryItemRow, Scope3SignificanceRow } from '../../models/refs.model';
import { Scope3ItemRow } from '../../models/scope3-summary.model';
import { Fr032Service } from './fr03-2.service';
import { Scope3SummaryService } from './scope3-summary.service';

export interface Fr032CanonicalRow extends Scope3SignificanceRow {
  isoNo: string;
}

export interface CanonicalCycleData {
  inventory: InventoryItemRow[];
  fr03_2: Fr032CanonicalRow[];
}

@Injectable({ providedIn: 'root' })
export class CanonicalGhgService {
  constructor(
    private scope3Svc: Scope3SummaryService,
    private fr032Svc: Fr032Service,
  ) {}

  /**
   * Build canonical datasets for export.
   * Today: Scope 3 comes from Scope3Screen store. Scope1/2 can be added later from Data Entry.
   */
  build(cycleId: number): CanonicalCycleData {
  // --- Scope 3 source ---
  const scope3Doc = this.scope3Svc.load(cycleId);
  const scope3Items: Scope3ItemRow[] =
    scope3Doc?.rows?.length ? scope3Doc.rows : this.scope3Svc.getMockRows(cycleId);

  // ensure computed fields exist
  this.computeScope3(scope3Items);

  // --- Scope 1/2 placeholders (ยังไม่ทำก็ return [] ได้เลย) ---
  const inventoryScope1: InventoryItemRow[] = this.buildScope1Inventory(cycleId);
  const inventoryScope2: InventoryItemRow[] = this.buildScope2Inventory(cycleId);

  // --- Scope 3 canonical inventory ---
  const inventoryScope3: InventoryItemRow[] =
    scope3Items.map((it: Scope3ItemRow) => this.mapScope3ToInventory(it));

  // --- merged inventory ---
  const inventory: InventoryItemRow[] = [
    ...inventoryScope1,
    ...inventoryScope2,
    ...inventoryScope3,
  ];

  // --- FR-03.2 canonical (significance result per Scope3 item) ---
  const saved = this.fr032Svc.load(cycleId) || {};
  const fr03_2: Fr032CanonicalRow[] = [];

  for (const it of scope3Items) { // it ถูก infer เป็น Scope3ItemRow แล้ว
    const subScope = this.parseSubScope(it.tgoNo);
    const itemLabel = (it.itemName ?? it.itemLabel) || '';
    const key = `${subScope}|${itemLabel}`;
    const savedRow = saved[key] || {};

    fr03_2.push({
      key,
      subScope,
      isoNo: this.parseIsoNo(it.scopeIso),
      categoryLabel: it.categoryLabel,
      itemLabel,
      ghgTco2e: Number(it.totalTco2e || 0),
      sharePct: Number(it.sharePct || 0),
      assessment: (savedRow as any).assessment ?? '',
      selection: (savedRow as any).selection ?? '',
    });
  }

  return { inventory, fr03_2 };
}

public buildCanonicalForCycle(cycleId: number): CanonicalCycleData {
  return this.build(cycleId);
}

private buildScope1Inventory(_cycleId: number): InventoryItemRow[] {
  return []; // TODO: ต่อ 1.1/1.2
}

private buildScope2Inventory(_cycleId: number): InventoryItemRow[] {
  return []; // TODO: ต่อ 2.1/2.2
}

  private mapScope3ToInventory(it: Scope3ItemRow): InventoryItemRow {
    const subScope = this.parseSubScope(it.tgoNo);
    const itemLabel = (it.itemName ?? it.itemLabel) || '';

    return {
      id: `S3:${subScope}:${slug(itemLabel)}`,
      scope: 3,
      subScope,
      tgoNo: it.tgoNo,
      isoScope: it.scopeIso,
      categoryLabel: it.categoryLabel,
      itemLabel,
      unit: it.unit,
      quantityPerYear: Number(it.quantityPerYear || 0),
      remark: it.remark ?? '',
      dataEvidence: it.dataEvidence ?? '',
      ef: Number(it.ef || 0),
      efEvidence: it.efEvidence ?? '',
      totalTco2e: Number(it.totalTco2e || 0),
      sharePct: Number(it.sharePct || 0),
      trace: it.refs ? {
        itemLabel: it.refs.itemLabel,
        unit: it.refs.unit,
        quantity: it.refs.quantityPerYear,
        dataEvidence: it.refs.dataEvidence,
        ef: it.refs.ef,
        efEvidence: it.refs.efEvidence,
      } : undefined,
    };
  }

  private computeScope3(items: Scope3ItemRow[]) {
    for (const r of items) {
      const qty = Number(r.quantityPerYear || 0);
      const ef = Number(r.ef || 0);
      r.totalTco2e = (qty * ef) / 1000;
      // compatibility
      r.ghgTco2e = r.totalTco2e;
    }
    const total = items.reduce((s, r) => s + Number(r.totalTco2e || 0), 0);
    for (const r of items) {
      r.sharePct = total > 0 ? (Number(r.totalTco2e || 0) / total) * 100 : 0;
      // compatibility
      r.pct = r.sharePct;
    }
  }

  private parseSubScope(tgoNo: string): string {
    // "Scope 3.1" -> "3.1"; already "3.1" -> "3.1"
    const s = String(tgoNo || '').replace(/scope\s*/i, '').trim();
    return s;
  }

  private parseIsoNo(scopeIso: string): string {
    // "Scope 4.1 in ISO 14064-1" -> "4.1" (best-effort)
    const m = String(scopeIso || '').match(/(\d+(?:\.\d+)?)/);
    return m ? m[1] : '';
  }
}

function slug(s: string): string {
  return String(s || '')
    .trim()
    .toLowerCase()
    .replace(/\s+/g, '-')
    .replace(/[^a-z0-9\-_.]+/g, '');
}
